package com.ksb.board;

public class Dto {
public String num;
public String content;
public String title;
public String id;

public Dto(String title, String content,String id){
	this.title=title;
	this.content=content;
	this.id=id;
}

public Dto(String num,String title,String content, String id) {
	this.num=num;
	this.title=title;
	this.content=content;
	this.id=id;
}
public Dto(String title,String content) {
	this.title=title;
	this.content=content;
}
}
