package com.ksb.board;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.ksb.util.Cw;

public class Dao extends Da{
	
public ArrayList<Dto> list(String page) {
	super.connect();
	ArrayList<Dto> posts=new ArrayList<>();
	try {
		
		int startIndex=((Integer.parseInt(page))-1)*3;
		
	String sql = String.format(
			"select*from %s limit %s,3", Db.BOARD,startIndex);
	Cw.wn(sql);
	ResultSet rs=st.executeQuery(sql);
	while(rs.next()) {
		posts.add(new Dto(
				rs.getString("num"),
				rs.getString("title"),
				rs.getString("content"),
				rs.getString("id")
				));
	}
	}catch(Exception e) {
		e.printStackTrace();
	}
	super.close();
	return posts;
}
	public void write(Dto d) {
		super.connect();
		String sql=String.format(
				"insert into %s (title,content,id) values ('%s','%s','%s');",
				Db.BOARD,d.title,d.content,d.id);
		System.out.println(sql);
		super.update(sql);
		super.close();
		
		}
	
public Dto read(String num) {
	super.connect();
	Dto post=null;
	try {
		
		String sql= String.format(
				"select*from %s where %s",Db.BOARD,num);
		System.out.println(sql);
		ResultSet rs=st.executeQuery(sql);
		rs.next();
		post=new Dto(
				rs.getString("num"),
				rs.getString("title"),
				rs.getString("content"),
				rs.getString("id")
				);
	}catch(Exception e) {
		e.printStackTrace();
	}
	super.close();
	return post;
}

public void del(String num){
	super.connect();
	String sql= String.format(
				"delete from %s where num=%s",Db.BOARD,num);
		super.update(sql);
		super.close();
}
public void edit(Dto d,String num) {
		super.connect();
		String sql=String.format(
				"update %s set title='%s',content='%s' where num=%s",Db.BOARD,d.title,d.content,num);
		System.out.println(sql);
		super.update(sql);
		super.close();
	
}

public int getPostCount(){
	int count=0;
	super.connect();
	try {
		String sql = String.format(
				"select count(*) from %s",
				Db.BOARD);
		Cw.wn(sql);
		ResultSet rs= st.executeQuery(sql);
		rs.next();
		count = rs.getInt("count(*)");
		
	}catch(Exception e) {
		e.printStackTrace();
	}
	super.close();
	return count;
}

public int getSearchPostCount(String word) {
	int count=0;
	super.connect();
	try {
		String sql=String.format(
				"select count(*) from %s where title like '%%%s%%'"
				,Db.BOARD,word);
		Cw.wn(sql);
		ResultSet rs=st.executeQuery(sql);
		rs.next();
		count = rs.getInt("count(*)");
		
	}catch(Exception e) {
		e.printStackTrace();
	}
	super.close();
	return count;
	
}
public ArrayList<Dto> listSearch(String word,String page){
	super.connect();
	ArrayList<Dto> posts=new ArrayList<>();
	try {
		int startIndex=((Integer.parseInt(page))-1)*3;
		
		String sql= String.format(
				"select * from %s where title like '%%%s%%' limit %s,3"
				,Db.BOARD,word,page
				);
		Cw.wn(sql);
		ResultSet rs=st.executeQuery(sql);
		while(rs.next()) {
			posts.add(new Dto(
					rs.getString("num"),
					rs.getString("title"),
					rs.getString("content"),
					rs.getString("id")
					));
		}
	}catch(Exception e) {
		e.printStackTrace();
	}
	super.close();
	return posts;
}
public int getTotalPageCount(){
	int totalPageCount=0;
	int count = getPostCount();
	
	if(count %3 == 0) {
		totalPageCount=count/3;
	}else {
		totalPageCount=count/3+1;
	}
	return totalPageCount;
}
public int getSearchTotalPageCount(String word) {
	int totalPageCount=0;
	int count = getSearchPostCount(word);
	
	if(count%3==0) {
		totalPageCount=count/3;
	}else {
		totalPageCount=count/3+1;
	}
	return totalPageCount;
}
}
 